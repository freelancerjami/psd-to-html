<?php







require_once('dbcon.php');
session_start();
if (isset($_SESSION['user_login'])) {
    header('location:index.php');
}


if (isset($_POST['login'])) {
    
    $username=mysqli_real_escape_string($link,$_POST['username']);
    $password=mysqli_real_escape_string($link,$_POST['password']);
    $creatauth=md5(sha1($password.$username));
    $username_chack=mysqli_query($link,"SELECT * FROM `user` WHERE `username`='$username';");

    if(mysqli_num_rows($username_chack)){

       $row=mysqli_fetch_assoc($username_chack);

      if ($row['auth']== $creatauth) {
          if ($row['stats']=='active') {
             
              $_SESSION['user_login']=$username;
              header('location:index.php');
          }else{
            $stats_inactive="Inactive";
          }
      }else{
        $password_not_match="Password not match";
      }

    }else{
        $username_not_found="This username not found";
    }

}











?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Student manegment system</title>
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container mt-5 ">
        <h1 class="text-center">Student manegment system</h1>
         <div class="row">
            <div class="col-sm-4 offset-sm-4">
                <h2 class="text-center">Admin Login Form</h2>
                <form action="" method="post">
                    <div>
                        <input type="text"  name="username" required="" placeholder="username" class="form-control" value="<?php if(isset($username)){ echo $username;}?>">
                        <p class="error"><?php if(isset($username_not_found)){ echo $username_not_found;} ?></p>
                    </div>
                    <div class="my-2">
                        <input type="text" name="password"  required="" placeholder="password" class="form-control" value="<?php if(isset($password)){ echo $password;}?>">
                        <p class="error">
                            <?php if(isset($password_not_match)){ echo $password_not_match;} ?>
                            <?php if(isset($stats_inactive)){ echo $stats_inactive;} ?>
                        </p>
                    </div>
                    <div>
                        <input type="submit" name="login"  value="login" class="btn btn-info float-right">
                    </div>
                </form>
                <div class="back-page">
                  <a href="../index.php"> Back</a>
                </div>
            </div>
         </div>
    </div>
</body>
</html>