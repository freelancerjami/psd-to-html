<?php

require_once('dbcon.php');
$id=base64_decode($_GET['id']);
$delete_data="DELETE FROM `student-info` WHERE `id`='$id'";
$delete_query=mysqli_query($link,$delete_data);

if ($delete_query) {
	header('location:index.php?page=all-students');
}else{
	echo "Data not delete";
}















?>