

<div class="content">
<h1 class="text-primary"><i class="fas fa-user-plus"></i> All Users <small>All Users</small></h1>
<nav aria-label="breadcrumb">
	<ol class="breadcrumb">
		 <li><a href="index.php?page=dashboard">Dashboard</a> /   </li>
		 <li class="breadcrumb-item active" aria-current="page"><i class="fas fa-user-plus"></i> All Users </li>
    </ol>
</nav>
	<div class="table-responsive table-responsive-sm table-responsive-md">
		<table id="data" class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th>Name</th>
					<th>Email</th>
					<th>UserName</th>
					<th>Photo</th><!-- 
					<th>Stats</th>
					<th>Acrion</th> -->
				</tr>
			</thead>
			<tbody>

				<?php
				$query_select=mysqli_query($link,"SELECT * FROM `user`");
				while ( $row=mysqli_fetch_assoc($query_select)) {?>
					<tr>
						<td><?php echo ucwords($row['name']); ?></td>
						<td><?php echo $row['email']; ?></td>
						<td><?php echo $row['username']; ?></td>
						<td>
							<img style="width: 40px; text-align: center;" src="images/<?php echo $row['photo']; ?>" alt="">
						</td>
						<!-- <td><?php echo $row['stats']; ?></td>
						 -->
						<!-- <td>
							<a class="btn btn-warning " href="index.php?page=update_student&id=<?php echo base64_encode($row['id']); ?>"> <i class="fas fa-pencil"></i> Edit</a>
							<a class="btn btn-danger" href="delete_student.php?id=<?php echo base64_encode($row['id']); ?>"> Delete</a>
						</td> -->
					</tr>
				<?php }?>
			</tbody>
		</table>
	</div>
</div>