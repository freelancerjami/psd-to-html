
<div class="content">
	<h1 class="text-primary"><i class="fas fa-user-plus"></i> Add Student <small>Add new Student</small></h1>
<nav aria-label="breadcrumb">
	<ol class="breadcrumb">
		 <li><a href="index.php?page=dashboard">Dashboard</a> /   </li>
		 <li class="breadcrumb-item active" aria-current="page"><i class="fas fa-user-plus"></i> Add Student </li>
    </ol>
</nav>
<?php
require_once('dbcon.php');

if (isset($_POST['add-student'])) {
	$name=$_POST['name'];
	$roll=$_POST['roll'];
	$class=$_POST['class'];
	$city=$_POST['city'];
	$pcontact=$_POST['pcontact'];

	$photo=explode('.', $_FILES['photo']['name']);
	$photo_extention=end($photo);
	$photo_name=$roll.'.'.$photo_extention;
	

	$query="INSERT INTO `student-info`( `name`, `roll`, `class`, `city`, `pcontact`, `photo`) VALUES ('$name','$roll','$class','$city','$pcontact','$photo_name');";

	$result=mysqli_query($link,$query);

	if ($result) {
		move_uploaded_file($_FILES['photo']['tmp_name'], 'add-student-images/'.$photo_name);

		$success="Student Add Successful!";
		// header('location:add-student.php');
	}else{
		$error="Student Add Falied!";
	}



}


?>






<div class="row">
	<div class="col-sm-6">
		<form action="" method="POST" enctype="multipart/form-data">
			
			
			<?php 
				if (isset($success)) {
					echo "<p class='alert alert-success'>".$success."</p>";
				}
				
			?>
			<?php
				if (isset($error)){
					echo "<p class='alert alert-danger'>".$error."</p>";
				}
			?>

			<div class="form-group">
				<label for="name">Student Name</label>
				<input type="text" class="form-control" placeholder="Student Name" name="name" id="name" required="">
			</div>
			<div class="form-group">
				<label for="roll">Student Roll</label>
				<input type="text" class="form-control" placeholder="Roll" name="roll" id="roll" pattern="[0-9]{6}"required="">
			</div>
			<div class="form-group">
				<label for="class">Class</label>
				<select name="class" id="class" class="form-control" required="">
					<option value="select">select</option>
					<option value="1st">1st</option>
					<option value="2nd">2nd</option>
					<option value="3rd">3rd</option>
					<option value="4th">4th</option>
					<option value="5th">5th</option>
				</select>
			</div>
			<div class="form-group">
				<label for="city">City</label>
				<input type="text" class="form-control" placeholder="City" name="city" id="city" required="">
			</div>
			<div class="form-group">
				<label for="pcontact">Contact Number</label>
				<input type="text" class="form-control" placeholder="01*******" pattern="+8801[1|3|5|6|7|8|9][0-9]{8}" name="pcontact" id="pcontact" required="">
			</div>
			<div class="form-group">
				<label for="photo ">Picture</label>
				<input style="display: block"  type="file" name="photo" id="photo" required="">
			</div>
			<div class="form-group float-right">
				<input type="submit" class="btn btn-primary" value="Add Student" name="add-student">
			</div>
		</form>
	</div>
</div>
</div>
