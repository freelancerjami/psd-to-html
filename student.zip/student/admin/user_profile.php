<div class="content">
	<h1 class="text-primary"><i class="fas fa-user"></i> Profile <small>My profile</small></h1>
	<nav aria-label="breadcrumb">
	   <ol class="breadcrumb">
		 <li class="breadcrumb-item active" aria-current="page"><a href="index.php?page=dashboard"><i class="fas fa-tachometer-alt"></i> Dashboard </a></li>
		 <li class="breadcrumb-item active" aria-current="page"><i class="fas fa-user"></i> Profile </li>
	   </ol>
	</nav>



<?php

$user_session=$_SESSION['user_login'];

$user_data=mysqli_query($link,"SELECT * FROM `user` WHERE `username`='$user_session'");
$user_row=mysqli_fetch_assoc($user_data);

?>

	<div class="row">
		<div class="col-sm-6">
			<table class="table table-bordered">
				<tr>
					<td>User Id</td>
					<td><?php echo $user_row['id'] ; ?></td>
				</tr>
				<tr>
					<td>Name</td>
					<td><?php echo ucwords($user_row['name']) ; ?></td>
				</tr>
				<tr>
					<td>Username</td>
					<td><?php echo $user_row['username'] ; ?></td>
				</tr>
				<tr>
					<td>Email</td>
					<td><?php echo $user_row['email'] ; ?></td>
				</tr>
				<tr>
					<td>Stats</td>
					<td><?php echo ucwords($user_row['stats'] ); ?></td>
				</tr>
				<tr>
					<td>SignUp Date</td>
					<td><?php echo $user_row['time'] ; ?></td>
				</tr>
			</table>
			<a class="btn btn-warning " href="index.php?page=user_update_profile&id=<?php echo base64_encode($user_row['id']); ?>"> Edit Profle</a>
		</div>

		<div class="col-sm-6">
			<a href="">
				<img width="300px" src="images/<?php echo $user_row['photo'] ; ?>" alt="" class="img-thumbnail">
			</a>



		<?php

			if (isset($_POST['update-profile'])) {

				$photo=(explode('.',$_FILES['photo']['name']));
				$photo=end($photo);
				$photo_name=$user_session.'.'.$photo;
				$upload=mysqli_query($link,"UPDATE `user` SET `photo`='$photo_name' WHERE `username`='$user_session'");
				if ($upload) {
					move_uploaded_file($_FILES['photo']['tmp_name'],'images/'.$photo_name);
				}
			}


		?>


			<form action="" method="POST" class="pt-5" enctype="multipart/form-data">
				<label for="photo" style="display: block;">Profile Picture</label>
				<input type="file" name="photo" id="photo">
				<input type="submit" name="update-profile" value="Upload " class="btn btn-primary">
			</form>
		</div>
	</div>
</div>