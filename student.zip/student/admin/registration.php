<?php

require_once('dbcon.php');
session_start();
if(isset($_POST['registration'])){
print_r($_FILES['photo']);
	$name=mysqli_real_escape_string($link,$_POST['name']);
	$email=mysqli_real_escape_string($link,$_POST['email']);
	$username=mysqli_real_escape_string($link,$_POST['username']);
	$password=mysqli_real_escape_string($link,$_POST['password']);
	// $c_password=mysqli_real_escape_string($link,$_POST['c_password']);
    $encryptedPwd=md5(sha1($password));
    $auth=md5(sha1($password.$username));	

	 $photo=(explode('.',  $_FILES['photo']['name']));
	$photo=end($photo);
	$photo_name=$username.'.'.$photo;
	

	$input_error=array();

	if (empty($name)) {
		$input_error['name']="The name fild is requried ";
	}
	if (empty($email)) {
		$input_error['email']="The Email fild is requried ";
	}
	if (empty($username)) {
		$input_error['username']="The Username fild is requried ";
	}
	if (empty($password)) {
		$input_error['password']="The Password fild is requried ";
	}
	// if (empty($c_password)) {
	// 	$input_error['c_password']="The Conform Password fild is requried ";
	// }
	

	if (count($input_error)==0) {

		$email_select="SELECT * FROM `user` WHERE `email`='$email';";
		$username_select="SELECT * FROM `user` WHERE `username`='$username';";

		$email_chack=mysqli_query($link,$email_select);
		
		if(mysqli_num_rows($email_chack)===0) {
			$username_chack=mysqli_query($link,$username_select);
			if (mysqli_num_rows($username_chack)===0) {
				
				if (strlen($username)>7) {
					if (strlen($password)>7) {
						if ($password) {
							
							$insert_query="INSERT INTO `user`(`name`, `email`, `username`, `encryptedPwd`,`auth`, `photo`, `stats`) VALUES ('$name','$email','$username','$encryptedPwd','$auth','$photo_name','inactive');";
							$result=mysqli_query($link,$insert_query);
							if ($result) {
								$_SESSION['data_insert_success']="Data insert successful!";
								move_uploaded_file($_FILES['photo']['tmp_name'], 'images/'.$photo_name);
								header('location:registration.php');
							}else{
								$_SESSION['data_inset_error']="Data inset Error";
							}

						}else{
							$password_not_match="Password not match";
						}
					}else{
						$password_len="Password more than 8 characters";
					}
				}else{
					$username_len="Username more than 8 characters";
				}
			}else{
				$username_error="This Username Already Exisit";
			}
		}else{
			$email_error=" This Eamil Already Exists";
		}
	}



}















?>













<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Registration From</title>
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container mt-5 ">
        <h1 class="text-center"> User Registration From</h1>
        <?php 
        	if (isset($_SESSION['data_insert_success'])) {
        		echo "<div class='alert alert-success'>".$_SESSION['data_insert_success']."</div>";
        	}
            // unset($_SESSION['data_insert_success']);
        ?>
        <?php 
            if (isset($_SESSION['data_insert_error'])) {
                echo "<div class='alert alert-warning'>".$_SESSION['data_insert_error']."</div>";
            }
        ?>
        <hr>
         <div class="row">
            <div class="col-sm-6 offset-sm-3">
                <form action="" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                    	<label for="name" >Name</label>
                        <div class="">
                        	<input type="text" id="name" name="name" placeholder="Enter your name" class="form-control" value="<?php if(isset($name)){ echo $name;}?>">
                        </div> 
                        <label class="error">
                        	<?php if (isset($input_error['name'])) {echo $input_error['name'];}?>
                        </label>
                    </div>
                    
                    <div class="form-group">
                    	<label for="email" >Email</label>
                        <input type="email" id="email" name="email" placeholder="Enter your Email" class="form-control" value="<?php if(isset($email)){ echo $email;}?>"> 
                        <label class="error">
                        	<?php if (isset($input_error['email'])) {echo $input_error['email'];}?>
                        	<?php if (isset($email_error)) {echo $email_error;}?>
                        </label>
                    </div>
                    <div class="form-group">
                    	<label for="username" >Username</label>
                        <input type="text" id="username" name="username" placeholder="Enter your username" class="form-control" value="<?php if(isset($username)){ echo $username;}?>">
                        <label class="error">
                        	<?php if (isset($input_error['username'])) {echo $input_error['username'];}?>
                        	<?php if (isset($username_error)) {echo $username_error;}?>
                        	<?php if (isset($username_len)) {echo $username_len;}?>
                        </label> 
                    </div>
                    <div class="form-group">
                    	<label for="password" >Password</label>
                        <input type="password" id="password" name="password" placeholder="Enter your password" class="form-control">
                        <label class="error">
                        	<?php if (isset($input_error['password'])) {echo $input_error['password'];}?>
                        	<?php if (isset($password_len)) {echo $password_len;}?>
                        </label>
                    </div>
                    <div class="form-group">
                    	<label for="c_password">Confiram password</label>
                        <input type="password" id="c_password" name="c_password" placeholder="Enter your Confiram Password" class="form-control" value="<?php if(isset($c_password)){ echo $c_password;}?>">
                        <label class="error">
                        	<?php if (isset($input_error['c_password'])) {echo $input_error['c_password'];}?>
                        	<?php if (isset($password_not_match)) {echo $password_not_match;}?>
                        </label>
                    </div>
                    <div class="form-group">
                    	<label for="photo">Photo</label>
                        <input type="file" id="photo" name="photo"> 
                    </div>
                    <div class="form-group"> 
                        <input  class="btn btn-info" type="submit" name="registration" value="Registration"> 
                    </div>
                    <p>If you have an account?then plase <a href="login.php">login</a></p>
                </form>
            </div>
         </div>
         <hr>
         <footer class="text-center">
         	<p>CopyRight &copy 2018-<?php echo date("Y")?> All Right Reserved</p>
         </footer>
    </div>
</body>
</html>