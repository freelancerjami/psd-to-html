
<div class="content">
	<h1 class="text-primary"><i class="fas fa-user-plus"></i> Update User Profile <small>Update User Profile</small></h1>
<nav aria-label="breadcrumb">
	<ol class="breadcrumb">
		 <li><a href="index.php?page=dashboard">Dashboard</a> / </li>
		 <li><a href="index.php?page=user_profile">User Profile</a> / </li>
		 <li class="breadcrumb-item active" aria-current="page"><i class="fas fa-user-plus"></i> Update User Profile </li>
    </ol>
</nav>
<?php
require_once('dbcon.php');



$id=base64_decode($_GET['id']);
$update="SELECT * FROM `user` WHERE `id`='$id';";
$update_query=mysqli_query($link,$update);
$row=mysqli_fetch_assoc($update_query);


if (isset($_POST['update-user'])) {

	$name=$_POST['name'];
	$username=$_POST['username'];
	$email=$_POST['email'];
	$update_query="UPDATE `user` SET `name`='$name',`email`='$email',`username`='$username' WHERE `id`='$id';";
	$result=mysqli_query($link,$update_query);
	if ($result) {
		header('location:index.php?page=user_profile');

	}
}


?>


<div class="row">
	<div class="col-sm-6">
		<form action="" method="POST" enctype="multipart/form-data">
			<div class="form-group">
				<label for="name"> Name</label>
				<input type="text" class="form-control" placeholder="Student Name" name="name" id="name" required="" value="<?php echo ucwords($row['name']); ?>">
			</div>
			<div class="form-group">
				<label for="username">User Name</label>
				<input type="text" class="form-control" placeholder="Roll" name="username" id="username" required="" value="<?php echo $row['username']; ?>">
			</div>
			<div class="form-group">
				<label for="emali">Email</label>
				<input type="text" class="form-control" placeholder="City" name="email" id="email" required="" value="<?php echo $row['email']; ?>">
			</div>
			<div class="form-group float-right">
				<input type="submit" class="btn btn-primary" value="Update User Profile" name="update-user">
			</div>
		</form>
	</div>
</div>
</div>
