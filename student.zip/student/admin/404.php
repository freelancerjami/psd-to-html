<div class="text-center text-danger">
	<h1>404</h1>
	<h1>Page Not Found</h1>
</div>