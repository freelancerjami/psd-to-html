
<div class="content">
	<h1 class="text-primary"><i class="fas fa-user-plus"></i> Update Student <small>Update new Student</small></h1>
<nav aria-label="breadcrumb">
	<ol class="breadcrumb">
		 <li><a href="index.php?page=dashboard">Dashboard</a> / </li>
		 <li><a href="index.php?page=all-students">All Students</a> / </li>
		 <li class="breadcrumb-item active" aria-current="page"><i class="fas fa-user-plus"></i> Update Student </li>
    </ol>
</nav>
<?php
require_once('dbcon.php');



$id=base64_decode($_GET['id']);
$update="SELECT * FROM `student-info` WHERE `id`='$id';";
$update_query=mysqli_query($link,$update);
$row=mysqli_fetch_assoc($update_query);


if (isset($_POST['update-student'])) {

	$name=$_POST['name'];
	$roll=$_POST['roll'];
	$class=$_POST['class'];
	$city=$_POST['city'];
	$pcontact=$_POST['pcontact'];

	// $photo=explode('.', $_FILES['photo']['name']);
	// $photo_extention=end($photo);
	// $photo_name=$roll.'.'.$photo_extention;
	

	$update_query="UPDATE `student-info` SET `name`='$name',`roll`='$roll',`class`='$class',`city`='$city',`pcontact`='$pcontact' WHERE `id`='$id';";
	$result=mysqli_query($link,$update_query);
	if ($result) {
		// move_uploaded_file($_FILES['photo']['tmp_name'], 'add-student-images/'.$photo_name);
		header('location:index.php?page=all-students');

	}




}


?>






<div class="row">
	<div class="col-sm-6">
		<form action="" method="POST" enctype="multipart/form-data">
			<div class="form-group">
				<label for="name">Student Name</label>
				<input type="text" class="form-control" placeholder="Student Name" name="name" id="name" required="" value="<?php echo ucwords($row['name']); ?>">
			</div>
			<div class="form-group">
				<label for="roll">Student Roll</label>
				<input type="text" class="form-control" placeholder="Roll" name="roll" id="roll" pattern="[0-9]{6}"required="" value="<?php echo $row['roll']; ?>">
			</div>
			<div class="form-group">
				<label for="class">Class</label>
				<select name="class" id="class" class="form-control" required="">
					<option value="select">select</option>
					<option <?php echo $row['class']=='1st' ? 'selected=""':''; ?> value="1st">1st</option>
					<option <?php echo $row['class']=='2nd' ? 'selected=""':''; ?> value="2nd">2nd</option>
					<option <?php echo $row['class']=='3rd' ? 'selected=""':''; ?> value="3rd">3rd</option>
					<option <?php echo $row['class']=='4th' ? 'selected=""':''; ?> value="4th">4th</option>
					<option <?php echo $row['class']=='5th' ? 'selected=""':''; ?> value="5th">5th</option>
				</select>
			</div>
			<div class="form-group">
				<label for="city">City</label>
				<input type="text" class="form-control" placeholder="City" name="city" id="city" required="" value="<?php echo ucwords($row['city']); ?>">
			</div>
			<div class="form-group">
				<label for="pcontact">Contact Number</label>
				<input type="text" class="form-control" placeholder="01*******" pattern="+8801[1|3|5|6|7|8|9][0-9]{8}" name="pcontact" id="pcontact" required="" value="<?php echo $row['pcontact']; ?>">
			</div>
			<!-- <div class="form-group">
				<label for="photo ">Picture</label>
				<input style="display: block"  type="file" name="photo" id="photo" value="<?php echo $row['photo']; ?>">
			</div> -->
			<div class="form-group float-right">
				<input type="submit" class="btn btn-primary" value="Update Student" name="update-student">
			</div>
		</form>
	</div>
</div>
</div>
