<?php

	$link=mysqli_connect("localhost","root","","student");

if (!$link==true) {
	echo "Databe not conneted";
}












?>