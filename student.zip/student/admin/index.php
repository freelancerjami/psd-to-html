
<?php
session_start();
require_once('dbcon.php');
if (!isset($_SESSION['user_login'])) {
	header('location:login.php');
}

?>
<?php

$user_session=$_SESSION['user_login'];

$user_data=mysqli_query($link,"SELECT * FROM `user` WHERE `username`='$user_session'");
$user_row=mysqli_fetch_assoc($user_data);

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="../css/all.css">
    <link rel="stylesheet" href="../css/style.css">

    <title>SMS</title>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
	  <a class="navbar-brand" href="index.php">SMS</a>

	  <div class="collapse navbar-collapse" id="navbarSupportedContent">
	    <ul class="navbar-nav ml-auto">
	      <li class="nav-item">
	      	</i><a class="nav-link" href="#"><i class="fas fa-user"></i> 

					<?php echo ucwords($user_row['name']) ;
	      	?>
	      </a>
	  	  </li>
	      <li class="nav-item">
	      	</i><a class="nav-link" href="index.php?page=registration"><i class="fas fa-user-plus"></i> Add user</a>
	      </li>
	      <li class="nav-item">
	      	</i><a class="nav-link" href="index.php?page=user_profile"><i class="fas fa-user"></i> Profile</a>
	      </li>
	      <li class="nav-item">
	      	</i><a class="nav-link" href="logout.php"><i class="fa fa-power-off"></i> Logout</a>
	      </li>
	    </ul>
	  </div>
	</nav>
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-3">
				<div class="list-group">
				  <a href="index.php?page=dashboard" class="list-group-item list-group-item-action active">
				    <i class="fas fa-tachometer-alt"></i> Dashboard
				  </a>
				  <a href="index.php?page=add-student" class="list-group-item list-group-item-action"><i class="fas fa-user-plus"></i> Add Student</a>
				  <a href="index.php?page=all-students" class="list-group-item list-group-item-action"><i class="fas fa-user-plus"></i> All Students</a>
				  <a href="index.php?page=all-user" class="list-group-item list-group-item-action"><i class="fas fa-user-plus"></i> All Users</a>
				</div>
			</div>
			<div class="col-sm-9">
				<?php 

				if (isset($_GET['page'])) {

					$page=$_GET['page'].'.php';

				}else{
					$page='dashboard.php';
				}

				
				if (file_exists($page)) {
					require_once($page);
				}else{
					require_once('404.php');
				}




				?>
			</div>
		</div>
<!-- Footer section -->
<footer class="page-footer font-small blue">
	<div class="footer-copyright text-center py-3">© 2018 Copyright:
    <a href=""> Students Manegmanet System All Rights are Reserved</a>
  </div>
</footer>

	</div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="../js/jquery-3.4.1.min.js"></script>
    <script src="../js/jquery.dataTables.min.js"></script>
    <script src="../js/dataTables.bootstrap4.min.js"></script>
    <script src="../js/main.js"></script>
  </body>
</html>