<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Student manegment system</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
         <div class="row">
             <div class="col-12">
             <a class="btn btn-primary float-right mt-5" href="admin/login.php">Login</a>
             </div>
         </div>
        <h1 class="text-center" >Welcome Student Manegment system</h1>

            <div class="col-sm-6 offset-sm-3 mt-3 mb-5">
                <form action="" method="post">
                <table class="table table-bordered">
                        <tr>
                            <td colspan="2" class="text-center"><label>Studen Information</label></td>
                        </tr>
                        <tr>
                            <td><label for="choose">Choose Class</label></td>
                            <td>
                                <select class="form-control" name="choose" id="choose">
                                    <option value="">Select</option>
                                    <option value="1st">1st</option>
                                    <option value="2nd">2nd</option>
                                    <option value="3rd">3rd</option>
                                    <option value="4th">4th</option>
                                    <option value="5th">5th</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td><label for="roll">Roll</label></td>
                            <td><input class="form-control" id="roll" type="text" name="roll" pattern="[0-9]{6}" placeholder="Roll"></td>
                        </tr>
                        <tr>
                            <td class="text-center" colspan="2"><input class="btn btn-info" type="submit" name="show_info" value="Show info"></label></td>
                        </tr>
                    </table>
                </form>
            </div>
        <?php
        require_once('admin/dbcon.php');
            if (isset($_POST['show_info'])) {
                $choose=$_POST['choose'];
                $roll=$_POST['roll'];
                $result=mysqli_query($link,"SELECT * FROM `student-info` WHERE `class`='$choose' AND `roll`='$roll'");
                if (mysqli_num_rows($result)==1) {
                    $row=mysqli_fetch_assoc($result);
                    ?>
                    <div class="row">
                <div class="col-sm-6 offset-sm-3">
                    <table class="table table-bordered" >
                        <tr>
                            <td rowspan="4" >
                                <img width="150px" class="img-thumbnail" src="admin/add-student-images/555555.jpg" alt="">
                            </td>
                            <td>Name</td>
                            <td><?= $row['name']; ?></td>
                        </tr>
                        <tr>
                            
                            <td>Roll</td>
                            <td><?= $row['roll']; ?></td>
                        </tr>
                        <tr>
                            
                            <td>Class</td>
                            <td><?= $row['class']; ?></td>
                        </tr>
                        <tr>
                            
                            <td>City</td>
                            <td><?= $row['city']; ?></td>
                        </tr>
                    </table>
                </div>
               </div>
               <?php }else{?>
                    <script type="text/javascript" >
                        alert('Data Not Fonud');
                    </script>
               <?php } }?>

            
    </div>
</body>
</html>